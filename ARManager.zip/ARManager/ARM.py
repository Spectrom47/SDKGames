
 #____                                 __                                  
#/\  _`\                              /\ \__                               
#\ \,\L\_\    _____      __     ___   \ \ ,_\   _ __    ___     ___ ___    
 #\/_\__ \   /\ '__`\  /'__`\  /'___\  \ \ \/  /\`'__\ / __`\ /' __` __`\  
  # /\ \L\ \ \ \ \L\ \/\  __/ /\ \__/   \ \ \_ \ \ \/ /\ \L\ \/\ \/\ \/\ \ 
  # \ `\____\ \ \ ,__/\ \____\\ \____\   \ \__\ \ \_\ \ \____/\ \_\ \_\ \_\
   # \/_____/  \ \ \/  \/____/ \/____/    \/__/  \/_/  \/___/  \/_/\/_/\/_/
    #           \ \_\                                                      
     #           \/_/                                                      
                
                        
# Fullscreen Crew Manager — ARM label moved to bottom-left of screen (outside hero)
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import shutil, os, datetime, tkinter.font as tkfont

# -------------------------
# Paths / Config
# -------------------------
BASE_DIR = Path(__file__).parent
TEMPLATE_FOLDER = BASE_DIR / "FolderTwo"
TARGET_FOLDER = BASE_DIR / "FolderThree"
TERMINATED_FOLDER = TARGET_FOLDER / "Terminated"
TARGET_FOLDER.mkdir(exist_ok=True)
TERMINATED_FOLDER.mkdir(exist_ok=True)

BG_COLOR = "#f3f4f6"
CARD_BG = "#ffffff"
PRIMARY_BTN = "#0052cc"
SECONDARY_BTN = "#0b5dd7"
RESET_BTN = "#cc1f1f"
BTN_TEXT = "white"
LABEL_COLOR = "#111827"
MAX_POINTS_BEFORE_TERMINATION = 6

# -------------------------
# Small data helpers (unchanged)
# -------------------------
def employee_folders():
    out = []
    if TARGET_FOLDER.exists():
        for p in sorted(TARGET_FOLDER.iterdir()):
            if p.is_dir() and p.name != "Terminated":
                out.append(p)
    return out

def ensure_employee_files(folder: Path):
    if not (folder / "Points.txt").exists():
        (folder / "Points.txt").write_text("0", encoding="utf-8")
    if not (folder / "Infractions.log").exists():
        (folder / "Infractions.log").write_text("", encoding="utf-8")

def read_points(folder: Path) -> int:
    p = folder / "Points.txt"
    try:
        return int(p.read_text(encoding="utf-8").strip() or 0)
    except Exception:
        return 0

def write_points(folder: Path, points: int):
    (folder / "Points.txt").write_text(str(points), encoding="utf-8")

def append_infraction(folder: Path, infraction_type: str, reason: str):
    log = folder / "Infractions.log"
    timestamp = datetime.datetime.now().isoformat(sep=" ", timespec="seconds")
    entry = f"[{timestamp}] {infraction_type} - {reason}\n"
    log.open("a", encoding="utf-8").write(entry)

def read_infractions(folder: Path, max_lines=50) -> str:
    log = folder / "Infractions.log"
    if not log.exists():
        return ""
    lines = log.read_text(encoding="utf-8").splitlines()
    return "\n".join(lines[-max_lines:])

def terminate_employee(folder: Path) -> Path:
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    new_name = f"{folder.name}_TERMINATED_{timestamp}"
    dest = TERMINATED_FOLDER / new_name
    shutil.move(str(folder), str(dest))
    return dest

def make_folder_name(first: str, last: str) -> str:
    first = first.strip(); last = last.strip()
    if first and last: return f"{last}, {first}"
    return first or last

def sanitize_name_for_fs(name: str) -> str:
    return "".join(c for c in name if c.isalnum() or c in (" ", "_", "-", ",")).strip()

def clone_folder(first_name: str, last_name: str) -> Path:
    raw = make_folder_name(first_name, last_name)
    safe = sanitize_name_for_fs(raw)
    if not safe:
        raise ValueError("Invalid name - supply first and/or last name.")
    new_folder = TARGET_FOLDER / safe
    if new_folder.exists():
        i = 1
        while (TARGET_FOLDER / f"{safe}_{i}").exists(): i += 1
        new_folder = TARGET_FOLDER / f"{safe}_{i}"
    new_folder.mkdir()
    if TEMPLATE_FOLDER.exists():
        for item in TEMPLATE_FOLDER.iterdir():
            dest = new_folder / item.name
            if item.is_dir(): shutil.copytree(item, dest)
            else: shutil.copy2(item, dest)
    ensure_employee_files(new_folder)
    return new_folder

def add_infraction_to_folder(folder: Path, inf_type: str, reason: str):
    pts = read_points(folder) + 1
    append_infraction(folder, inf_type, reason)
    write_points(folder, pts)
    return pts

def decrease_point_for_folder(folder: Path):
    pts = max(0, read_points(folder) - 1)
    write_points(folder, pts)
    append_infraction(folder, "ManualDecrease", "Point manually decreased")
    return pts

def reset_points_for_folder(folder: Path):
    write_points(folder, 0)
    append_infraction(folder, "ResetPoints", "Points reset to 0 by manager")

# -------------------------
# Tk root + fullscreen + scaling
# -------------------------
root = tk.Tk()
root.configure(bg=BG_COLOR)
screen_w = root.winfo_screenwidth(); screen_h = root.winfo_screenheight()
root.geometry(f"{screen_w}x{screen_h}+0+0")
root.overrideredirect(True)
is_fullscreen = True

def toggle_fullscreen(event=None):
    global is_fullscreen
    if is_fullscreen:
        root.overrideredirect(False)
        root.geometry(f"{int(screen_w*0.9)}x{int(screen_h*0.9)}+{int(screen_w*0.05)}+{int(screen_h*0.05)}")
        is_fullscreen = False
    else:
        root.overrideredirect(True)
        root.geometry(f"{screen_w}x{screen_h}+0+0")
        is_fullscreen = True
    position_arm()  # reposition ARM when toggling

def exit_confirm_and_quit(event=None):
    if messagebox.askyesno("Exit Application", "Are you sure you want to exit the application?"):
        root.destroy()

root.bind_all("<F11>", toggle_fullscreen)
root.bind_all("<Control-q>", exit_confirm_and_quit)

# baseline scale and fonts (roomier)
BASE_W, BASE_H = 1366, 768
scale = min(max(screen_w / BASE_W, screen_h / BASE_H), 2.5)
header_font = tkfont.Font(family="Segoe UI Semibold", size=max(14, int(26 * scale)))
label_font  = tkfont.Font(family="Segoe UI", size=max(11, int(14 * scale)))
entry_font  = tkfont.Font(family="Segoe UI", size=max(11, int(13 * scale)))
mono_font   = tkfont.Font(family="Consolas", size=max(10, int(12 * scale)))

style = ttk.Style(root)
try: style.theme_use("clam")
except: pass
style.configure("Card.TFrame", background=CARD_BG)
style.configure("Header.TLabel", font=header_font, background=CARD_BG, foreground=LABEL_COLOR)
style.configure("Label.TLabel", font=label_font, background=CARD_BG, foreground=LABEL_COLOR)
style.configure("TEntry", padding=int(8 * scale))
style.configure("TCombobox", padding=int(6 * scale))
style.configure("Primary.TButton", background=PRIMARY_BTN, foreground=BTN_TEXT, font=("Segoe UI Semibold", max(11, int(12 * scale))))
style.map("Primary.TButton", background=[("active", PRIMARY_BTN)])
style.configure("Danger.TButton", background=RESET_BTN, foreground=BTN_TEXT)
style.configure("Secondary.TButton", background=SECONDARY_BTN, foreground=BTN_TEXT)

# spacing constants
PAD_X = int(18 * scale)
PAD_Y = int(14 * scale)
CARD_PADDING = int(20 * scale)
GAP = int(18 * scale)

# -------------------------
# container and screens
# -------------------------
container = ttk.Frame(root, style="Card.TFrame", padding=CARD_PADDING)
container.pack(fill="both", expand=True, padx=PAD_X, pady=PAD_Y)
container.columnconfigure(0, weight=3); container.columnconfigure(1, weight=2)
container.rowconfigure(0, weight=1)

create_screen = ttk.Frame(container, style="Card.TFrame")
infraction_screen = ttk.Frame(container, style="Card.TFrame")

def show_create_screen(): infraction_screen.grid_forget(); create_screen.grid(row=0, column=0, sticky="nsew"); refresh_roster_all()
def show_infraction_screen(): create_screen.grid_forget(); infraction_screen.grid(row=0, column=0, sticky="nsew"); refresh_roster_all(); roster_listbox_inflection.focus_set()

# -------------------------
# Create screen (header changed to ARM hero box — without "(ARM)")
# -------------------------
hero_height = max(110, int(110 * scale))
hero = tk.Frame(create_screen, bg=CARD_BG, bd=2, relief="solid")
hero.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, GAP))
hero.grid_columnconfigure(0, weight=1)
hero_interior = tk.Frame(hero, bg=CARD_BG, padx=int(18*scale), pady=int(14*scale))
hero_interior.grid(row=0, column=0, sticky="nsew")

# Header title inside hero — without the (ARM) subtitle
title_label = tk.Label(hero_interior, text="Associate Management Roster", bg=CARD_BG, fg=LABEL_COLOR, font=("Segoe UI Semibold", max(18, int(30*scale))))
title_label.grid(row=0, column=0, sticky="w")

# continue with the rest of the layout below the hero
form_card = ttk.Frame(create_screen, style="Card.TFrame", padding=(CARD_PADDING))
form_card.grid(row=1, column=0, sticky="nsew", padx=(0, GAP))
roster_card = ttk.Frame(create_screen, style="Card.TFrame", padding=(CARD_PADDING))
roster_card.grid(row=1, column=1, sticky="nsew", padx=(GAP, 0))
form_card.columnconfigure(1, weight=1); form_card.columnconfigure(3, weight=1)

# --- form fields (same as before) ---
ttk.Label(form_card, text="First Name", style="Label.TLabel").grid(row=0, column=0, sticky="w", pady=(0, GAP))
first_entry = ttk.Entry(form_card, font=entry_font); first_entry.grid(row=0, column=1, sticky="ew", padx=(int(8*scale), int(16*scale)), pady=(0, GAP))
ttk.Label(form_card, text="Last Name", style="Label.TLabel").grid(row=0, column=2, sticky="w", pady=(0, GAP))
last_entry = ttk.Entry(form_card, font=entry_font); last_entry.grid(row=0, column=3, sticky="ew", pady=(0, GAP))

ttk.Label(form_card, text="Job (Position ID)", style="Label.TLabel").grid(row=1, column=0, sticky="w", pady=(0, GAP))
job_entry = ttk.Entry(form_card, font=entry_font); job_entry.grid(row=1, column=1, sticky="ew", padx=(int(8*scale), int(16*scale)), pady=(0, GAP))
ttk.Label(form_card, text="Employment Type", style="Label.TLabel").grid(row=1, column=2, sticky="w", pady=(0, GAP))
employment_var = tk.StringVar(); employment_box = ttk.Combobox(form_card, textvariable=employment_var, values=["Full-Time","Part-Time","Seasonal","Temp"], state="readonly", font=entry_font)
employment_box.grid(row=1, column=3, sticky="ew", pady=(0, GAP)); employment_box.set("Full-Time")

ttk.Label(form_card, text="Pay", style="Label.TLabel").grid(row=2, column=0, sticky="w", pady=(0, GAP))
pay_var = tk.StringVar(); pay_box = ttk.Combobox(form_card, textvariable=pay_var, values=["Associate ($15.50/hr)","Supervisor ($22/hr)","Manager ($65,000/yr)","Custom"], state="readonly", font=entry_font)
pay_box.grid(row=2, column=1, sticky="ew", padx=(int(8*scale), int(16*scale)), pady=(0, GAP)); pay_box.set("Associate ($15.50/hr)")
ttk.Label(form_card, text="Custom Pay", style="Label.TLabel").grid(row=2, column=2, sticky="w", pady=(0, GAP))
custom_pay_entry = ttk.Entry(form_card, font=entry_font); custom_pay_entry.grid(row=2, column=3, sticky="ew", pady=(0, GAP)); custom_pay_entry.config(state="disabled")
def on_pay_change(event=None):
    if pay_var.get()=="Custom": custom_pay_entry.config(state="normal"); custom_pay_entry.focus_set()
    else: custom_pay_entry.delete(0,tk.END); custom_pay_entry.config(state="disabled")
pay_box.bind("<<ComboboxSelected>>", on_pay_change)

ttk.Label(form_card, text="Work Description", style="Label.TLabel").grid(row=3, column=0, sticky="w", pady=(0, GAP))
work_var = tk.StringVar(); work_box = ttk.Combobox(form_card, textvariable=work_var, values=["Flooring","Paint","Millworks","Cashier","Custom"], state="readonly", font=entry_font)
work_box.grid(row=3, column=1, sticky="ew", padx=(int(8*scale), int(16*scale)), pady=(0, GAP)); work_box.set("Flooring")
ttk.Label(form_card, text="Custom Work (if Custom chosen)", style="Label.TLabel").grid(row=3, column=2, sticky="w", pady=(0, GAP))
custom_work_entry = ttk.Entry(form_card, font=entry_font); custom_work_entry.grid(row=3, column=3, sticky="ew", pady=(0, GAP)); custom_work_entry.config(state="disabled")
def on_work_change(event=None):
    if work_var.get()=="Custom": custom_work_entry.config(state="normal"); custom_work_entry.focus_set()
    else: custom_work_entry.delete(0,tk.END); custom_work_entry.config(state="disabled")
work_box.bind("<<ComboboxSelected>>", on_work_change)

btn_frame = ttk.Frame(form_card, padding=(int(8*scale))); btn_frame.grid(row=4, column=0, columnspan=4, pady=(int(18*scale),0), sticky="ew")
btn_frame.columnconfigure((0,1,2,3), weight=1)

def start_over():
    first_entry.delete(0,tk.END); last_entry.delete(0,tk.END); job_entry.delete(0,tk.END)
    employment_box.set("Full-Time"); pay_box.set("Associate ($15.50/hr)"); custom_pay_entry.delete(0,tk.END)
    custom_pay_entry.config(state="disabled"); work_box.set("Flooring"); custom_work_entry.delete(0,tk.END); custom_work_entry.config(state="disabled")
    first_entry.focus_set()

def save_entries():
    first = first_entry.get().strip(); last = last_entry.get().strip(); job = job_entry.get().strip()
    employment = employment_var.get(); pay = pay_var.get()
    if pay=="Custom": pay = custom_pay_entry.get().strip()
    work = work_var.get()
    if work=="Custom": work = custom_work_entry.get().strip()
    if not (first or last) or not job or not pay or not work:
        messagebox.showerror("Error", "Fill First or Last name, Job, Pay, and Work.")
        return
    try: cloned = clone_folder(first, last)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to create folder: {e}"); return
    (cloned/"FirstName.txt").write_text(first, encoding="utf-8")
    (cloned/"LastName.txt").write_text(last, encoding="utf-8")
    (cloned/"Job.txt").write_text(job, encoding="utf-8")
    (cloned/"Employment.txt").write_text(employment, encoding="utf-8")
    (cloned/"Pay.txt").write_text(pay, encoding="utf-8")
    (cloned/"Work.txt").write_text(work, encoding="utf-8")
    (cloned/"SavedAt.txt").write_text(datetime.datetime.now().isoformat(), encoding="utf-8")
    messagebox.showinfo("Saved", f"Employee created: {cloned.name}")
    start_over(); refresh_roster_all()

save_btn = ttk.Button(btn_frame, text="Save Employee (Ctrl+S)", style="Primary.TButton", command=save_entries); save_btn.grid(row=0,column=0,padx=8,pady=8,sticky="ew")
startover_btn = ttk.Button(btn_frame, text="Start Over (Esc)", style="Danger.TButton", command=start_over); startover_btn.grid(row=0,column=1,padx=8,pady=8,sticky="ew")
open_main_btn = ttk.Button(btn_frame, text="Employee Files", style="Secondary.TButton", command=lambda: open_path(TARGET_FOLDER)); open_main_btn.grid(row=0,column=2,padx=8,pady=8,sticky="ew")
infraction_nav_btn = ttk.Button(btn_frame, text="Infraction (F8)", style="Secondary.TButton", command=show_infraction_screen); infraction_nav_btn.grid(row=0,column=3,padx=8,pady=8,sticky="ew")

# Roster card
ttk.Label(roster_card, text="Roster", style="Header.TLabel").grid(row=0,column=0,sticky="w", pady=(0,GAP))
roster_listbox = tk.Listbox(roster_card, font=entry_font); roster_listbox.grid(row=1,column=0, sticky="nsew", pady=(int(6*scale),0))
roster_card.rowconfigure(1,weight=1)
roster_scroll = ttk.Scrollbar(roster_card, orient="vertical", command=roster_listbox.yview); roster_scroll.grid(row=1,column=1,sticky="ns")
roster_listbox.config(yscrollcommand=roster_scroll.set)
ttk.Label(roster_card, text="Selected:", style="Label.TLabel").grid(row=2,column=0,sticky="w", pady=(int(10*scale),0))
selected_label = ttk.Label(roster_card, text="", style="Label.TLabel"); selected_label.grid(row=3,column=0,sticky="w")

# -------------------------
# Infraction screen (kept responsive)
# -------------------------
header_inf = ttk.Label(infraction_screen, text="Infraction / Discipline", style="Header.TLabel"); header_inf.grid(row=0,column=0,columnspan=2,sticky="w", pady=(0,GAP))
back_btn = ttk.Button(infraction_screen, text="Back (Esc)", style="Secondary.TButton", command=show_create_screen); back_btn.grid(row=0,column=1,sticky="e")

roster_left = ttk.Frame(infraction_screen, style="Card.TFrame", padding=(int(12*scale))); roster_left.grid(row=1,column=0,sticky="nsew", padx=(0,GAP))
roster_left.columnconfigure(0,weight=1); roster_left.rowconfigure(0,weight=1)
roster_listbox_inflection = tk.Listbox(roster_left, font=entry_font); roster_listbox_inflection.grid(row=0,column=0,sticky="nsew")
roster_scroll2 = ttk.Scrollbar(roster_left, orient="vertical", command=roster_listbox_inflection.yview); roster_scroll2.grid(row=0,column=1,sticky="ns")
roster_listbox_inflection.config(yscrollcommand=roster_scroll2.set)

inf_right = ttk.Frame(infraction_screen, style="Card.TFrame", padding=(int(12*scale))); inf_right.grid(row=1,column=1,sticky="nsew", padx=(GAP,0))
inf_right.columnconfigure(1, weight=1)

emp_name_var = tk.StringVar(); emp_points_var = tk.StringVar(); emp_path_var = tk.StringVar()
ttk.Label(inf_right, text="Selected:", style="Label.TLabel").grid(row=0,column=0,sticky="w")
ttk.Label(inf_right, textvariable=emp_name_var, style="Label.TLabel").grid(row=0,column=1,sticky="w", padx=(8,0))
ttk.Label(inf_right, text="Points:", style="Label.TLabel").grid(row=1,column=0,sticky="w")
points_label = ttk.Label(inf_right, textvariable=emp_points_var, style="Label.TLabel"); points_label.grid(row=1,column=1,sticky="w")
ttk.Label(inf_right, text="Path:", style="Label.TLabel").grid(row=2,column=0,sticky="nw")
ttk.Label(inf_right, textvariable=emp_path_var, style="Label.TLabel", wraplength=int(700*scale), justify="left").grid(row=2,column=1,sticky="w", padx=(8,0))

ttk.Label(inf_right, text="Recent Infractions:", style="Label.TLabel").grid(row=3,column=0,columnspan=2,sticky="w", pady=(int(8*scale),0))
infractions_text = tk.Text(inf_right, font=mono_font); infractions_text.grid(row=4,column=0,columnspan=2,sticky="nsew", pady=(8,0))
inf_right.rowconfigure(4, weight=1)
infractions_scroll = ttk.Scrollbar(inf_right, orient="vertical", command=infractions_text.yview); infractions_scroll.grid(row=4,column=2,sticky="ns")
infractions_text.config(yscrollcommand=infractions_scroll.set, state="disabled")

infraction_controls = ttk.Frame(inf_right, style="Card.TFrame", padding=(int(8*scale))); infraction_controls.grid(row=5,column=0,columnspan=2,pady=(int(12*scale),0),sticky="ew")
infraction_var = tk.StringVar(value="attendance(late in)"); presets = ["attendance(late in)","attendance(call out)","attendance(Early Out)","Custom"]
def on_infraction_change():
    if infraction_var.get()=="Custom": custom_infraction_entry.config(state="normal"); custom_infraction_entry.focus_set()
    else: custom_infraction_entry.delete(0,tk.END); custom_infraction_entry.config(state="disabled")
for i,p in enumerate(presets):
    rb = ttk.Radiobutton(infraction_controls, text=p, variable=infraction_var, value=p, command=on_infraction_change); rb.grid(row=0,column=i,padx=int(10*scale),sticky="w")
ttk.Label(infraction_controls, text="Custom reason:", style="Label.TLabel").grid(row=1,column=0,sticky="w", pady=(int(8*scale),0))
custom_infraction_entry = ttk.Entry(infraction_controls, font=entry_font); custom_infraction_entry.grid(row=1,column=1,columnspan=3,pady=(int(8*scale),0),sticky="ew"); custom_infraction_entry.config(state="disabled")

infraction_btns = ttk.Frame(inf_right, style="Card.TFrame", padding=(int(8*scale))); infraction_btns.grid(row=6,column=0,columnspan=2,pady=(int(12*scale),0), sticky="ew")
infraction_btns.columnconfigure((0,1,2,3), weight=1)

def on_employee_select_infraction(event=None):
    sel = roster_listbox_inflection.curselection()
    if not sel:
        emp_name_var.set(""); emp_points_var.set(""); emp_path_var.set("")
        infractions_text.config(state="normal"); infractions_text.delete("1.0", tk.END); infractions_text.config(state="disabled"); return
    name = roster_listbox_inflection.get(sel[0]); folder = TARGET_FOLDER / name; ensure_employee_files(folder)
    emp_name_var.set(name); pts = read_points(folder); emp_points_var.set(str(pts))
    points_label.configure(foreground="#b91c1c" if pts >= MAX_POINTS_BEFORE_TERMINATION-1 else LABEL_COLOR)
    emp_path_var.set(str(folder))
    infractions_text.config(state="normal"); infractions_text.delete("1.0", tk.END); infractions_text.insert(tk.END, read_infractions(folder)); infractions_text.config(state="disabled")

def add_infraction():
    sel = roster_listbox_inflection.curselection()
    if not sel: messagebox.showerror("Select","Please select an employee."); return
    name = roster_listbox_inflection.get(sel[0]); folder = TARGET_FOLDER / name; ensure_employee_files(folder)
    if infraction_var.get()=="Custom":
        reason = custom_infraction_entry.get().strip()
        if not reason: messagebox.showerror("Error","Please enter a reason for the custom infraction."); return
        inf_type = "Custom"
    else:
        inf_type = infraction_var.get(); reason = inf_type
    pts = add_infraction_to_folder(folder, inf_type, reason); emp_points_var.set(str(pts))
    infractions_text.config(state="normal"); infractions_text.insert(tk.END, f"[{datetime.datetime.now().isoformat(sep=' ', timespec='seconds')}] {inf_type} - {reason}\n"); infractions_text.config(state="disabled")
    refresh_roster_all()
    if pts >= MAX_POINTS_BEFORE_TERMINATION:
        if messagebox.askyesno("Terminate", f"{name} has {pts} points. Terminate now?"):
            newp = terminate_employee(folder); messagebox.showinfo("Terminated", f"{name} moved to:\n{newp}"); refresh_roster_all()
            emp_name_var.set(""); emp_points_var.set(""); emp_path_var.set(""); infractions_text.config(state="normal"); infractions_text.delete("1.0", tk.END); infractions_text.config(state="disabled")

def decrease_point():
    sel = roster_listbox_inflection.curselection()
    if not sel: messagebox.showerror("Select","Please select an employee."); return
    name = roster_listbox_inflection.get(sel[0]); folder = TARGET_FOLDER / name; ensure_employee_files(folder)
    pts = decrease_point_for_folder(folder); emp_points_var.set(str(pts))
    infractions_text.config(state="normal"); infractions_text.insert(tk.END, f"[{datetime.datetime.now().isoformat(sep=' ', timespec='seconds')}] ManualDecrease - Point manually decreased\n"); infractions_text.config(state="disabled")
    refresh_roster_all()

def reset_points():
    sel = roster_listbox_inflection.curselection()
    if not sel: messagebox.showerror("Select","Please select an employee."); return
    name = roster_listbox_inflection.get(sel[0]); folder = TARGET_FOLDER / name; ensure_employee_files(folder)
    reset_points_for_folder(folder); emp_points_var.set("0")
    infractions_text.config(state="normal"); infractions_text.insert(tk.END, f"[{datetime.datetime.now().isoformat(sep=' ', timespec='seconds')}] ResetPoints - Points reset by manager\n"); infractions_text.config(state="disabled")
    refresh_roster_all()

add_inf_btn = ttk.Button(infraction_btns, text="Add Infraction", style="Primary.TButton", command=add_infraction); add_inf_btn.grid(row=0,column=0,padx=8,pady=8,sticky="ew")
decrease_btn = ttk.Button(infraction_btns, text="Decrease Point", style="Secondary.TButton", command=decrease_point); decrease_btn.grid(row=0,column=1,padx=8,pady=8,sticky="ew")
resetpoints_btn = ttk.Button(infraction_btns, text="Reset Points", style="Danger.TButton", command=reset_points); resetpoints_btn.grid(row=0,column=2,padx=8,pady=8,sticky="ew")
open_sel_btn = ttk.Button(infraction_btns, text="Open Folder", command=lambda: open_selected_folder_from_inf()); open_sel_btn.grid(row=0,column=3,padx=8,pady=8,sticky="ew")
roster_listbox_inflection.bind("<<ListboxSelect>>", on_employee_select_infraction)
roster_listbox.bind("<<ListboxSelect>>", lambda e: selected_label.config(text=roster_listbox.get(roster_listbox.curselection()[0]) if roster_listbox.curselection() else ""))

# -------------------------
# Fancy Exit hotspot — TOP RIGHT (morphs on hover to "Exit Application")
# -------------------------
def create_exit_hotspot_topright():
    size = max(38, int(36 * scale))
    pad = int(18 * scale)
    # compute position top-right
    x_pos = screen_w - pad - size
    y_pos = pad
    btn = tk.Button(root, text="✕", bg=RESET_BTN, fg="white", bd=0, relief="flat",
                    font=("Segoe UI Semibold", max(12, int(14 * scale))),
                    activebackground="#a61a1a", command=exit_confirm_and_quit)
    btn.place(x=x_pos, y=y_pos, width=size, height=size)
    orig = {"text":"✕", "bg":RESET_BTN, "width":size, "height":size}

    tip = tk.Label(root, text="Exit (Ctrl+Q)", bg="#111827", fg="white", font=("Segoe UI", max(9, int(10*scale))), padx=8, pady=4)
    tip.place_forget()

    def on_enter(e):
        # grow toward left so it doesn't overflow screen
        new_w = max(int(size * 4.2), 160)
        new_h = max(size + int(8*scale), 48)
        new_x = screen_w - pad - new_w
        btn.place_configure(x=new_x, y=y_pos, width=new_w, height=new_h)
        btn.config(text="Exit Application", bg="#b91c1c", fg="white")
        # show tooltip to the left above button
        tip_x = new_x - int(8*scale) - tip.winfo_reqwidth()
        tip_y = y_pos
        tip.place(x=max(8, tip_x), y=tip_y)
    def on_leave(e):
        btn.config(text=orig["text"], bg=orig["bg"], fg="white")
        btn.place_configure(x=x_pos, y=y_pos, width=orig["width"], height=orig["height"])
        tip.place_forget()

    btn.bind("<Enter>", on_enter)
    btn.bind("<Leave>", on_leave)

create_exit_hotspot_topright()

# -------------------------
# ARM floating label at BOTTOM-LEFT of screen (outside hero)
# -------------------------
arm_label = tk.Label(root, text="Version SDK 1.3", bg="#eef2ff", fg="#0b3fb5",
                     font=("Segoe UI Semibold", max(12, int(14 * scale))), bd=0, padx=int(12*scale), pady=int(6*scale))
arm_label.place(x=PAD_X, y=screen_h - PAD_Y - 40)  # initial; reposition below

def position_arm(event=None):
    # position ARM at bottom-left inside the current window bounds
    root.update_idletasks()
    w = root.winfo_width()
    h = root.winfo_height()
    # offset a little from edges
    x = PAD_X
    # compute label height and place it above bottom padding
    arm_h = arm_label.winfo_reqheight() or int(28 * scale)
    y = max(8, h - PAD_Y - arm_h)
    arm_label.place(x=x, y=y)

# reposition on configure and when toggling fullscreen
root.bind("<Configure>", position_arm)

# -------------------------
# Helpers: refresh and open paths
# -------------------------
def refresh_roster_all():
    names = [p.name for p in employee_folders()]
    roster_listbox.delete(0, tk.END); roster_listbox_inflection.delete(0, tk.END)
    for n in names:
        roster_listbox.insert(tk.END, n); roster_listbox_inflection.insert(tk.END, n)
    sel = roster_listbox.curselection(); selected_label.config(text=roster_listbox.get(sel[0]) if sel else "")

def open_path(path: Path):
    if not path.exists(): messagebox.showerror("Error", f"Path does not exist:\n{path}"); return
    try: os.startfile(str(path))
    except AttributeError:
        if os.name=="posix": os.system(f'xdg-open "{path}"')
        else: messagebox.showinfo("Info", f"Open folder manually: {path}")

def open_selected_folder_from_inf():
    sel = roster_listbox_inflection.curselection()
    if not sel: messagebox.showerror("Select","Please select an employee."); return
    folder = TARGET_FOLDER / roster_listbox_inflection.get(sel[0]); open_path(folder)

# -------------------------
# Initial run & bindings
# -------------------------
show_create_screen(); first_entry.focus_set(); refresh_roster_all()
position_arm()
root.bind_all("<Control-s>", lambda e: save_entries())
root.bind_all("<Escape>", lambda e: show_create_screen())
root.bind_all("<Control-q>", exit_confirm_and_quit)
root.bind_all("<F11>", toggle_fullscreen)
root.bind_all("<F8>", lambda e: show_infraction_screen())
root.mainloop()




